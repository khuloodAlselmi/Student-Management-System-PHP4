How to run the Student Management System (StudentMS) Project

1. Download the  zip file

2. Extract the file and copy studentms folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

4. Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with name studentmsdb

6. Import studentmsdb.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/studentms (frontend)



Credential for admin panel :

Username: admin
Password: Test@123

Credential for Student / User panel :

Username: anujk3
Password: Test@123

 Or Register a new Student/User.